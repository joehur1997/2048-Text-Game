Joseph Hur
Class ID: 67
Prof. Biswas

TwoDArray is a basic 2D array class. GameDisplay extends that class to create the board for the game. 
MainGame is the program that initializes a GameDisplay and uses it to play the game.